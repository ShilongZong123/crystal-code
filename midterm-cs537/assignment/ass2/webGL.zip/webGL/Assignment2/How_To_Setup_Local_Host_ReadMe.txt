Install Python: https://www.python.org/downloads/
Make sure Python executable is accessible in your PATH during install (Windows)
In a terminal (cmd) enter:

For Python 3:
In the command line:
cd to the folder containing the Common folder and the Assignment2 folder.
Run the command:
python -m http.server 8000

Access your project via the following typed into browser:
http://localhost:8000/Assignment2/bunny.html





