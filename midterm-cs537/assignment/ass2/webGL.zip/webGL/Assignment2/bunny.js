"use strict";

var canvas;
var gl;

var numVerticesInAllBunnyFaces;

var bunny_indices;
var bunny_vertices;
var bunny_bounding_box;    //Bunny's bounding box, [[minx,miny,minz],[maxx-minx,maxy-miny,maxz-minz]];
var m;

var program;    //shader program

var VIEW_TYPE = {//view type
    FRONT:0,
    BACK:1,
    TOP:2,
    BOTTOM:3,
    LEFT:4,
    RIGHT:5,
};

var position = [0,0,0];         //current position
var targetPosition = position;  //target Position
var moveSpeed = [0,0,0];        //Moving speed

var scaling = 1.0;              //Zoom factor
var rotationDegree = [0,0,0];   //Current rotation angle
var rotationSpeed = [0,0,0];    //Rotation speed

var viewType = VIEW_TYPE.FRONT; //Current view type

var matProjView;    //Projection matrix multiplied by camera matrix


// You probably don't want to change this function.
function loaded(data, _callback)
{
	m = loadOBJFromBuffer(data);
	console.log(m);
	bunny_indices = m.i_verts;
	bunny_vertices = m.c_verts;
	numVerticesInAllBunnyFaces = bunny_indices.length;
    bunny_bounding_box = cal_bounding_box(bunny_vertices);
	_callback();
}	

// Calculate bounding box
function cal_bounding_box(input_vertices)
{
    var minx = input_vertices[0];
    var miny = input_vertices[1];
    var minz = input_vertices[2];
    var maxx = minx;
    var maxy = miny;
    var maxz = minz;

    var num = input_vertices.length/3;
    for (var i = 1; i < num; i ++) {
        var x = input_vertices[i*3];
        var y = input_vertices[i*3+1];
        var z = input_vertices[i*3+2];

        if(x < minx) minx = x;
        if(x > maxx) maxx = x;

        if(y < miny) miny = y;
        if(y > maxy) maxy = y;

        if(z < minz) minz = z;
        if(z > maxz) maxz = z;

    }
	return [[minx,miny,minz],[maxx-minx,maxy-miny,maxz-minz]];
}

// You probably don't want to change this function.
window.onload = function init()
{
    canvas = document.getElementById( "gl-canvas" );

    gl = WebGLUtils.setupWebGL( canvas );
    if ( !gl ) { alert( "WebGL isn't available" ); }

    gl.viewport( 0, 0, canvas.width, canvas.height );
    gl.clearColor( 1.0, 1.0, 1.0, 1.0 );

	// Load OBJ file using objLoader.js functions
	// These callbacks ensure the data is loaded before rendering occurs.
	loadOBJFromPath("bunny.obj", loaded, setup_after_data_load);
}

// TODO: Edit this function.

window.addEventListener("keydown", function(){
    switch(event.keyCode) {
        case 38:  // up arrow key
            rotationSpeed[0] = -20; //Set the x-axis rotation speed
            break;
        case 40:  // down arrow key
            rotationSpeed[0] = 20;  //Set the x-axis rotation speed
            break;
        case 37: // left arrow key
            rotationSpeed[1] = -20; //Set the y-axis rotation speed
            break;
        case 39: // right arrow key
            rotationSpeed[1] = 20;  //Set the y-axis rotation speed
            break;
        case 32: // spacebar
            rotationSpeed = [0,0,0];    //Stop rotation
            //rotationDegree = [0,0,0];
            break;
    }
}, true);

//Set the rotation angle according to the view type
function resetViewType(newViewType) {
    viewType = newViewType;
    position = [0,0,0];
    moveSpeed = [0,0,0];
    rotationSpeed = [0,0,0];

    switch (viewType) {
    case VIEW_TYPE.FRONT:
        rotationDegree = [0,0,0];
        break;
    case VIEW_TYPE.BACK:
        rotationDegree = [0,180,0];
        break;
    case VIEW_TYPE.TOP:
        rotationDegree = [90,0,0];
        break;
    case VIEW_TYPE.BOTTOM:
        rotationDegree = [-90,0,0];
        break;
    case VIEW_TYPE.LEFT:
        rotationDegree = [0,90,0];
        break;
    case VIEW_TYPE.RIGHT:
        rotationDegree = [0,-90,0];
        break;
    }

}

// TODO: Edit this function.
function setup_after_data_load(){
	
	gl.enable(gl.DEPTH_TEST);

	//Set up the camera matrix and projection matrix
    var matProj = ortho(-0.5, 0.5, -0.5, 0.5,  1.0, 10.0 );
    var matView = lookAt([0,0,5] , [0.0,0.0,0.0],  [0,1,0]);
    matProjView = mult(matProj,matView);

    // Load shaders and initialize attribute buffers
    program = initShaders( gl, "vertex-shader", "fragment-shader" );
    gl.useProgram( program );

    // Array element buffer
    var iBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, iBuffer);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(bunny_indices), gl.STATIC_DRAW);

    // Vertex array attribute buffer
    var vBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, vBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, new Float32Array(bunny_vertices), gl.STATIC_DRAW );

    var vPosition = gl.getAttribLocation( program, "vPosition" );
    gl.vertexAttribPointer( vPosition, 3, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( vPosition );


    // Event listeners for button
    document.getElementById("slide").onchange = function() {
        var value = event.srcElement.value;
        scaling = 1 + 5 * value/100;    //Maximum zoom up to 6 times
    };

    document.getElementById( "frontButton" ).onclick = function () {
        resetViewType(VIEW_TYPE.FRONT);
    };
    document.getElementById( "backButton" ).onclick = function () {
        resetViewType(VIEW_TYPE.BACK);
    };
    document.getElementById( "topButton" ).onclick = function () {
        resetViewType(VIEW_TYPE.TOP);
    };
    document.getElementById( "bottomButton" ).onclick = function () {
        resetViewType(VIEW_TYPE.BOTTOM);
    };
    document.getElementById( "leftButton" ).onclick = function () {
        resetViewType(VIEW_TYPE.LEFT);
    };
    document.getElementById( "rightButton" ).onclick = function () {
        resetViewType(VIEW_TYPE.RIGHT);
    };

    canvas.onmousedown = function(){
        var x = event.clientX, y = event.clientY;
        var rect = event.target.getBoundingClientRect();
        if (x < rect.left) return ;
        if (x >= rect.right) return ;
        if (y < rect.top) return ;
        if (y >= rect.bottom) return ;
        x = x - rect.left;
        y = rect.bottom - y;

        //Mapped to [-1, +1]
        x = 2*(x / rect.width - 0.5);
        y = 2*(y / rect.height - 0.5);

        //Calculate the position in the camera coordinate system
        var cameraX = x / matProj[0][0];
        var cameraY = y / matProj[1][1];

        //Move to the target position within one second
        var moveTime = 1;
        targetPosition = [cameraX,cameraY,0.0];
        moveSpeed = [(targetPosition[0]-position[0])/moveTime,(targetPosition[1]-position[1])/moveTime,(targetPosition[2]-position[2])/moveTime];
    };


    render();	
}


//Calculate the angle after rotation
function rotate(degree,speed,time)
{
    if(speed > 0) {
        degree += speed * time;
        if(degree > 360) {
            degree -= 360;
        }
    }
    else if(speed < 0) {
        degree += speed * time;
        if(degree < 0) {
            degree += 360;
        }
    }
    return degree;
}

//Calculate position after moving
function move(pos,toPos,speed,time) {
    if (speed > 0) {
        pos += speed * time;
        if (pos > toPos) {
            pos = toPos;
        }
    }
    else if (speed < 0) {
        pos += speed * time;
        if (pos < toPos) {
            pos = toPos;
        }
    }
    return pos;
}
// TODO: Edit this function.
function render()
{
    var frameTime = 1/60;   //Time per frame

    //Calculate rotation and position
    for(var i = 0; i < 3; i ++) {
        rotationDegree[i] = rotate(rotationDegree[i],rotationSpeed[i],frameTime);   //
        position[i] = move(position[i],targetPosition[i],moveSpeed[i],frameTime);
    }

    gl.clear( gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.uniformMatrix4fv(gl.getUniformLocation(program,"uMatProjView"),false,flatten(matProjView));
    gl.uniform3fv(gl.getUniformLocation(program,"uPosCubeMin"),bunny_bounding_box[0]);
    gl.uniform3fv(gl.getUniformLocation(program,"uPosCubeSize"),bunny_bounding_box[1]);
    gl.uniform3fv(gl.getUniformLocation(program,"uPosition"),position);
    gl.uniform4fv(gl.getUniformLocation(program,"uRotationDegree"),[rotationDegree[0],rotationDegree[1],rotationDegree[2],scaling]);

    gl.drawElements( gl.TRIANGLES, bunny_indices.length, gl.UNSIGNED_SHORT, 0 );

    requestAnimFrame( render );
}

